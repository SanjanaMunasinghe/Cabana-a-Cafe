<?php
 $first name = $_post['first name'];
 $last name = $_post['last name'];
 $gender = $_post['gender'];
 $email = $_post['email'];
 $password = $_post['password'];
 $number = $_post['number'];

 //data base connection

 